var AccountService;

AccountService = (function() {
  function AccountService(settings) {
    this.settingsService = settings;
    this.lastEmail = window.localStorage.getItem('lastEmail');
  }

  AccountService.prototype.getInfo = function(email, password, cb) {
    this.lastEmail = email;
    window.localStorage.setItem('lastEmail', email, null);
    return $.ajax({
      url: (settingsService.hostUrl + "/user").replace('//', '/'),
      method: "POST",
      headers: {
        'Contact-Token': settingsService.contactToken
      },
      data: JSON.stringify({
        user: {
          email: email,
          password: password
        }
      }),
      contentType: "application/json; charset=utf-8",
      dataType: 'json',
      success: function(data) {
        return cb(null, data);
      },
      error: function(data) {
        return cb(data, null);
      }
    });
  };

  return AccountService;

})();
