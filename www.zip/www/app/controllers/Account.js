var Account;

Account = (function() {
  function Account(service) {
    var that;
    this.service = service;
    this.el = $('<div/>');
    this.render;
    that = this;
    this.el.on('click', '#startCheck', function(evt) {
      evt.preventDefault();
      return that.startCheck();
    });
  }

  Account.prototype.startCheck = function() {
    return this.service.getInfo($('#email').val(), $('#password').val(), function(err, data) {
      var app, i, info, j, len, len1, percentage, ref, ref1, ret, service;
      if (err) {
        return alert('Invalid user');
      } else {
        data = data['user'];
        $('#loginForm').hide();
        info = $('#informations');
        info.show();
        info.html('');
        ret = '<ul class="table-view">';
        ret += '<li class="table-view-divider">Program</li>';
        ret += '<li class="table-view-cell"><strong>Type: </strong> ' + data['program']['program'] + '</li>';
        percentage = 100 * (data['program']['today'] / data['program']['total']);
        ret += "<li class='table-view-cell'><strong>Requests left:</strong><br /><div class='chart' data-percent='" + percentage + "'><span>" + percentage + "</span>%</div></li>";
        ret += '<li class="table-view-divider">Applications</li>';
        ref = data['apps'];
        for (i = 0, len = ref.length; i < len; i++) {
          app = ref[i];
          ret += "<li class='table-view-cell'>";
          ret += "<strong>" + app['name'] + "<strong><br /><ul>";
          ref1 = app['channels'];
          for (j = 0, len1 = ref1.length; j < len1; j++) {
            service = ref1[j];
            ret += "<li>" + service['service'] + " - " + service['name'] + "</li>";
          }
          ret += "</ul></li>";
        }
        ret += '</ul>';
        return info.html(ret).promise().done(function() {
          return $('.chart').easyPieChart({
            animate: 1000,
            onStep: function(value) {
              return $(this.el).find('span').text(~~value);
            }
          });
        });
      }
    });
  };

  Account.prototype.render = function() {
    this.el.html(this.template(this.service));
    return this;
  };

  return Account;

})();
