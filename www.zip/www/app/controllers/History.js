var History;

History = (function() {
  function History(service) {
    var that;
    this.service = service;
    this.el = $('<div/>');
    that = this;
    this.render;
  }

  History.prototype.render = function() {
    this.el.html(this.template(this.service));
    return this;
  };

  return History;

})();
