http_path = '/'
css_dir = '../../lib'
sass_dir = '.'
output_style = :compact
line_comments = false
